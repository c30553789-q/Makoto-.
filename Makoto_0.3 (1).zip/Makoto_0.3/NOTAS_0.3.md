# Notas Makoto 0.3

- llama.cpp se clona en CI (`app/src/main/cpp/llama.cpp`), no va en el repo.
- Solo ABI arm64-v8a.
- NDK 27.2.12479018 + CMake 3.22.1.
- La API de llama.cpp cambia entre tags; el workflow usa `b10502` por defecto (ajustable).
- Carga por FD usa `/proc/self/fd/N` (puede fallar con algunos proveedores SAF; en ese caso copiar el GGUF a almacenamiento interno accesible).
- Sampling greedy simple (sin temperature) para mantener el código pequeño.
