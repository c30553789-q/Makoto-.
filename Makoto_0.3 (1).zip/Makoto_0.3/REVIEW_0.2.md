# Revisión de Makoto 0.2 (post-correcciones finales)

## Estado

Se aplicaron las correcciones solicitadas y se generó el Gradle Wrapper real.

## Correcciones realizadas

1. **Errores de compilación**
   - `modelScanError` gestionado en el ViewModel.
   - `findGgufFiles` (suspend) solo se llama desde coroutines + `Dispatchers.IO`.

2. **Operaciones de disco**
   - Lecturas/escrituras de JSON en `Dispatchers.IO` a través del ViewModel.

3. **ViewModel ligero**
   - `MakotoViewModel` concentra el estado necesario sin arquitectura pesada.

4. **Gradle Wrapper**
   - Se generó e incluyó `gradlew`, `gradlew.bat` y `gradle/wrapper/gradle-wrapper.jar` (Gradle 8.13).

5. **Modelo GGUF**
   - Sigue siendo externo al APK.
   - SAF + permisos persistentes + detección de `.gguf`.

6. **Papelera**
   - Se añadió botón sencillo para mover conversaciones a la papelera desde el historial.

## Qué no se tocó (a propósito)

- No se integró motor de inferencia.
- No se añadieron servicios externos.
- Se conservó la interfaz `InferenceEngine` para la fase 0.3.

## Limitaciones conocidas

- No se realizó una compilación completa con Android SDK en este entorno.
- No hay iconos de launcher personalizados (usará el por defecto del sistema).
- Las versiones de Compose BOM / AGP son las del proyecto original (2026.x). Si en el momento del build alguna no resolviera, se ajustarían en CI.

## Preparación para 0.3

La separación UI → ViewModel → repositorios → almacenamiento + la interfaz `InferenceEngine` permite añadir el motor GGUF sin reescribir el cuerpo.
