#include <jni.h>
#include <android/log.h>
#include <algorithm>
#include <string>
#include <vector>
#include <mutex>
#include <atomic>
#include <cstdio>
#include <unistd.h>

#include "llama.h"

#define LOG_TAG "MakotoJNI"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

static std::mutex g_mutex;
static llama_model * g_model = nullptr;
static llama_context * g_ctx = nullptr;
static std::atomic<bool> g_stop{false};

static void free_all_locked() {
    if (g_ctx) {
        llama_free(g_ctx);
        g_ctx = nullptr;
    }
    if (g_model) {
        llama_model_free(g_model);
        g_model = nullptr;
    }
}

static int load_from_path(const char * path, int n_ctx, int n_threads) {
    std::lock_guard<std::mutex> lock(g_mutex);
    free_all_locked();
    g_stop = false;

    llama_backend_init();

    llama_model_params mparams = llama_model_default_params();
    mparams.n_gpu_layers = 0; // solo CPU en tablet

    g_model = llama_model_load_from_file(path, mparams);
    if (!g_model) {
        LOGE("llama_model_load_from_file failed: %s", path);
        return 1;
    }

    llama_context_params cparams = llama_context_default_params();
    cparams.n_ctx = n_ctx > 0 ? n_ctx : 2048;
    cparams.n_threads = n_threads > 0 ? n_threads : 2;
    cparams.n_threads_batch = cparams.n_threads;

    g_ctx = llama_init_from_model(g_model, cparams);
    if (!g_ctx) {
        LOGE("llama_init_from_model failed");
        llama_model_free(g_model);
        g_model = nullptr;
        return 2;
    }

    LOGI("model loaded path ctx=%d threads=%d", cparams.n_ctx, cparams.n_threads);
    return 0;
}

static int load_from_fd(int fd, int n_ctx, int n_threads) {
    // llama.cpp no tiene load-from-fd estable en todas las versiones.
    // Duplicamos el FD a un path temporal vía /proc/self/fd/N (Linux/Android).
    char linkpath[64];
    snprintf(linkpath, sizeof(linkpath), "/proc/self/fd/%d", fd);
    char realpath_buf[1024];
    ssize_t n = readlink(linkpath, realpath_buf, sizeof(realpath_buf) - 1);
    if (n < 0) {
        LOGE("readlink failed for fd %d", fd);
        return 3;
    }
    realpath_buf[n] = '\0';
    // Algunos proveedores dan paths no legibles; intentamos igual.
    return load_from_path(realpath_buf, n_ctx, n_threads);
}

extern "C" JNIEXPORT jint JNICALL
Java_com_makoto_app_ai_LlamaNative_nativeLoad(JNIEnv * env, jclass, jstring jpath, jint nCtx, jint nThreads) {
    const char * path = env->GetStringUTFChars(jpath, nullptr);
    int rc = load_from_path(path, nCtx, nThreads);
    env->ReleaseStringUTFChars(jpath, path);
    return rc;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_makoto_app_ai_LlamaNative_nativeLoadFd(JNIEnv *, jclass, jint fd, jint nCtx, jint nThreads) {
    return load_from_fd(fd, nCtx, nThreads);
}

extern "C" JNIEXPORT void JNICALL
Java_com_makoto_app_ai_LlamaNative_nativeStop(JNIEnv *, jclass) {
    g_stop = true;
}

extern "C" JNIEXPORT void JNICALL
Java_com_makoto_app_ai_LlamaNative_nativeUnload(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_mutex);
    free_all_locked();
}

extern "C" JNIEXPORT jint JNICALL
Java_com_makoto_app_ai_LlamaNative_nativeGenerate(JNIEnv * env, jclass, jstring jprompt, jint maxTokens, jobject sink) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model || !g_ctx) return 10;
    g_stop = false;

    const char * prompt = env->GetStringUTFChars(jprompt, nullptr);
    std::string prompt_str(prompt);
    env->ReleaseStringUTFChars(jprompt, prompt);

    const llama_vocab * vocab = llama_model_get_vocab(g_model);
    std::vector<llama_token> tokens;
    tokens.resize(prompt_str.size() + 16);
    int n = llama_tokenize(vocab, prompt_str.c_str(), (int32_t)prompt_str.size(),
                           tokens.data(), (int32_t)tokens.size(), true, true);
    if (n < 0) {
        tokens.resize(-n);
        n = llama_tokenize(vocab, prompt_str.c_str(), (int32_t)prompt_str.size(),
                           tokens.data(), (int32_t)tokens.size(), true, true);
    }
    if (n < 0) {
        LOGE("tokenize failed");
        return 11;
    }
    tokens.resize(n);

    llama_batch batch = llama_batch_init((int32_t)tokens.size(), 0, 1);
    for (int i = 0; i < n; ++i) {
        batch.token[i] = tokens[i];
        batch.pos[i] = i;
        batch.n_seq_id[i] = 1;
        batch.seq_id[i][0] = 0;
        batch.logits[i] = (i == n - 1);
    }
    batch.n_tokens = n;

    if (llama_decode(g_ctx, batch) != 0) {
        LOGE("decode prompt failed");
        llama_batch_free(batch);
        return 12;
    }
    llama_batch_free(batch);

    jclass sinkClass = env->GetObjectClass(sink);
    jmethodID onToken = env->GetMethodID(sinkClass, "onToken", "(Ljava/lang/String;)V");
    if (!onToken) {
        LOGE("TokenSink.onToken not found");
        return 13;
    }

    int n_cur = n;
    int n_gen = 0;
    std::vector<llama_token> recent;  // últimos tokens generados (anti-repetición)
    const int max_gen = maxTokens > 0 ? maxTokens : 512;

    while (n_gen < max_gen && !g_stop) {
        auto * logits = llama_get_logits_ith(g_ctx, -1);
        // Penalización simple de repetición sobre los últimos tokens distintos
        if (!recent.empty()) {
            std::vector<llama_token> uniq(recent);
            std::sort(uniq.begin(), uniq.end());
            uniq.erase(std::unique(uniq.begin(), uniq.end()), uniq.end());
            for (llama_token t : uniq) {
                if (t >= 0 && t < llama_vocab_n_tokens(vocab)) {
                    if (logits[t] > 0) logits[t] /= 1.15f; else logits[t] *= 1.15f;
                }
            }
        }
        // sampling greedy simple
        int n_vocab = llama_vocab_n_tokens(vocab);
        llama_token best = 0;
        float best_logit = logits[0];
        for (int i = 1; i < n_vocab; ++i) {
            if (logits[i] > best_logit) {
                best_logit = logits[i];
                best = i;
            }
        }
        if (llama_vocab_is_eog(vocab, best)) break;
        recent.push_back(best);
        if (recent.size() > 64) recent.erase(recent.begin());

        char buf[256];
        int len = llama_token_to_piece(vocab, best, buf, sizeof(buf), 0, true);
        if (len > 0) {
            std::string piece(buf, len);
            jstring jpiece = env->NewStringUTF(piece.c_str());
            env->CallVoidMethod(sink, onToken, jpiece);
            env->DeleteLocalRef(jpiece);
            if (env->ExceptionCheck()) {
                env->ExceptionClear();
                break;
            }
        }

        llama_batch b2 = llama_batch_init(1, 0, 1);
        b2.token[0] = best;
        b2.pos[0] = n_cur;
        b2.n_seq_id[0] = 1;
        b2.seq_id[0][0] = 0;
        b2.logits[0] = true;
        b2.n_tokens = 1;
        if (llama_decode(g_ctx, b2) != 0) {
            llama_batch_free(b2);
            LOGE("decode token failed");
            return 14;
        }
        llama_batch_free(b2);
        n_cur++;
        n_gen++;
    }

    // limpiar KV para la siguiente generación (simple)
    llama_memory_clear(llama_get_memory(g_ctx), true);
    return 0;
}
