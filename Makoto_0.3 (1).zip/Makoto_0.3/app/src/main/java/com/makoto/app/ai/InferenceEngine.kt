package com.makoto.app.ai

interface InferenceEngine {
    val isReady: Boolean

    fun loadModel(modelPath: String): Result<Unit>

    /** Carga desde un descriptor de archivo (SAF / DocumentFile). */
    fun loadModelFd(fd: Int): Result<Unit> = Result.failure(
        UnsupportedOperationException("Este motor no soporta carga por descriptor")
    )

    fun generate(prompt: String, onToken: (String) -> Unit): Result<Unit>

    fun stop() {}

    /** Cambia los hilos de CPU; se aplica al volver a cargar el modelo. */
    fun setThreads(n: Int) {}

    fun unload()
}
