package com.makoto.app.ai

/**
 * Puente JNI mínimo hacia llama.cpp.
 * Las funciones nativas viven en libmakoto_jni.so
 */
object LlamaNative {

    interface TokenSink {
        fun onToken(token: String)
    }

    @JvmStatic
    var loadError: Throwable? = null
        private set

    init {
        try {
            System.loadLibrary("makoto_jni")
        } catch (t: Throwable) {
            // Se deja registrar el fallo; el engine lo detectará.
            loadError = t
        }
    }

    external fun nativeLoad(path: String, nCtx: Int, nThreads: Int): Int

    external fun nativeLoadFd(fd: Int, nCtx: Int, nThreads: Int): Int

    external fun nativeGenerate(prompt: String, maxTokens: Int, sink: TokenSink): Int

    external fun nativeStop()

    external fun nativeUnload()
}
