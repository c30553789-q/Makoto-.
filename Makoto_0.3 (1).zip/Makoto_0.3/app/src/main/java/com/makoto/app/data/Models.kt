package com.makoto.app.data

data class ChatMessage(val id: Long, val text: String, val fromUser: Boolean)

data class Conversation(
    val id: Long,
    val title: String,
    val messages: List<ChatMessage>,
    val deletedAt: Long? = null
)

data class MemoryItem(val id: Long, val text: String, val createdAt: Long)
