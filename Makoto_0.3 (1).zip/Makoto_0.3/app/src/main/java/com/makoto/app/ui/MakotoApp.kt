package com.makoto.app.ui

import android.net.Uri
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.makoto.app.MakotoViewModel
import com.makoto.app.data.ChatMessage
import com.makoto.app.data.Conversation
import com.makoto.app.data.MemoryItem

private enum class Screen { CHAT, HISTORY, MEMORY, TRASH, SETTINGS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MakotoApp(viewModel: MakotoViewModel = viewModel()) {
    val active by viewModel.active.collectAsState()
    val trash by viewModel.trash.collectAsState()
    val memory by viewModel.memory.collectAsState()
    val selectedId by viewModel.selectedId.collectAsState()
    val selectedTree by viewModel.selectedTree.collectAsState()
    val modelCount by viewModel.modelCount.collectAsState()
    val modelScanError by viewModel.modelScanError.collectAsState()
    val status by viewModel.status.collectAsState()
    val partial by viewModel.partial.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val threads by viewModel.threads.collectAsState()
    val lastSpeed by viewModel.lastSpeed.collectAsState()

    var screen by remember { mutableStateOf(Screen.CHAT) }
    var input by remember { mutableStateOf("") }
    var pendingDelete by remember { mutableStateOf<Long?>(null) }

    val selected = active.firstOrNull { it.id == selectedId } ?: active.firstOrNull()

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            viewModel.saveModelTree(uri)
        }
    }

    if (pendingDelete != null) {
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Eliminar conversación") },
            text = { Text("Se borrará definitivamente. Esta acción no se puede deshacer.") },
            confirmButton = {
                Button(onClick = {
                    viewModel.permanentlyDelete(pendingDelete!!)
                    pendingDelete = null
                }) { Text("Eliminar") }
            },
            dismissButton = {
                Button(onClick = { pendingDelete = null }) { Text("Cancelar") }
            }
        )
    }

    BackHandler(enabled = screen != Screen.CHAT) {
        screen = if (screen == Screen.TRASH) Screen.HISTORY else Screen.CHAT
    }

    when (screen) {
        Screen.CHAT -> ChatScreen(
            selected = selected,
            status = status,
            partial = partial,
            isGenerating = isGenerating,
            onStop = { viewModel.stopReply() },
            speed = lastSpeed,
            input = input,
            onInput = { input = it },
            onSend = {
                viewModel.sendMessage(input)
                input = ""
            },
            onHistory = { screen = Screen.HISTORY },
            onMemory = { screen = Screen.MEMORY },
            onSettings = { screen = Screen.SETTINGS }
        )
        Screen.HISTORY -> HistoryScreen(
            items = active,
            selectedId = selectedId,
            onSelect = { id ->
                viewModel.selectConversation(id)
                screen = Screen.CHAT
            },
            onTrash = { screen = Screen.TRASH },
            onNew = {
                viewModel.createConversation()
                screen = Screen.CHAT
            },
            onMoveToTrash = { id -> viewModel.moveToTrash(id) }
        )
        Screen.MEMORY -> MemoryScreen(
            items = memory,
            onAdd = { viewModel.addMemory(it) },
            onDelete = { viewModel.deleteMemory(it) }
        )
        Screen.TRASH -> TrashScreen(
            items = trash,
            onRestore = { viewModel.restore(it) },
            onDelete = { pendingDelete = it },
            onBack = { screen = Screen.HISTORY }
        )
        Screen.SETTINGS -> SettingsScreen(
            selectedTree = selectedTree,
            modelCount = modelCount,
            modelScanError = modelScanError,
            onPick = { folderPicker.launch(null) },
            onClear = { viewModel.clearModelTree() },
            threads = threads,
            onThreads = { viewModel.setThreads(it) },
            onBack = { screen = Screen.CHAT }
        )
    }
}

private val SakuraPink = Color(0xFFF9A8D4)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChatScreen(
    selected: Conversation?,
    status: String?,
    partial: String,
    isGenerating: Boolean,
    onStop: () -> Unit,
    speed: String?,
    input: String,
    onInput: (String) -> Unit,
    onSend: () -> Unit,
    onHistory: () -> Unit,
    onMemory: () -> Unit,
    onSettings: () -> Unit
) {
    val listState = rememberLazyListState()
    val messages = selected?.messages ?: emptyList()
    val canSend = isGenerating || input.isNotBlank()
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar()
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Makoto", fontWeight = FontWeight.Bold)
                            Text(
                                "IA local · sin internet",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onHistory) { Text("🕘") }
                    IconButton(onClick = onMemory) { Text("🧠") }
                    IconButton(onClick = onSettings) { Text("⚙") }
                }
            )
        },
        bottomBar = {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .navigationBarsPadding()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = onInput,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Escribe un mensaje...") },
                    shape = RoundedCornerShape(24.dp),
                    maxLines = 5
                )
                Spacer(Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .padding(bottom = 4.dp)
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(
                            if (canSend) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .clickable(enabled = canSend) {
                            if (isGenerating) onStop() else onSend()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (isGenerating) "■" else "➤",
                        color = if (canSend) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (messages.isEmpty() && partial.isBlank() && status == null) {
                item { WelcomeCard() }
            }
            items(messages, key = { it.id }) { message ->
                MessageBubble(message)
            }
            if (speed != null && !isGenerating) {
                item {
                    Text(
                        text = speed,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 40.dp)
                    )
                }
            }
            item {
                if (partial.isNotBlank()) {
                    AssistantRow(partial)
                } else if (status != null) {
                    TypingIndicator(status)
                }
            }
            item { Spacer(Modifier.height(12.dp)) }
        }
    }
    LaunchedEffect(selected?.messages?.size, partial.length, status) {
        val total = listState.layoutInfo.totalItemsCount
        if (total > 0) {
            listState.scrollToItem(total - 1)
        }
    }
}

private fun copyToClipboard(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Makoto", text))
    Toast.makeText(context, "Copiado", Toast.LENGTH_SHORT).show()
}

@Composable
private fun Avatar() {
    Box(
        modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(Color(0x33F9A8D4)),
        contentAlignment = Alignment.Center
    ) {
        Text("🌸", fontSize = 16.sp)
    }
}

@Composable
private fun WelcomeCard() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 64.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🌸", fontSize = 56.sp)
        Spacer(Modifier.height(12.dp))
        Text("Hola, soy Makoto", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(
            "Corro solo en esta tablet.\nSin internet y sin nube.",
            textAlign = TextAlign.Center,
            color = SakuraPink
        )
    }
}

@Composable
private fun TypingIndicator(label: String) {
    var dots by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(400)
            dots = (dots + 1) % 4
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Avatar()
        Spacer(Modifier.width(8.dp))
        Text(
            text = label.trimEnd('…', '.') + ".".repeat(dots),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun AssistantRow(text: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Avatar()
        Spacer(Modifier.width(8.dp))
        Text(
            text = text,
            modifier = Modifier
                .widthIn(max = 300.dp)
                .background(
                    MaterialTheme.colorScheme.surfaceVariant,
                    RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomEnd = 18.dp, bottomStart = 4.dp)
                )
                .padding(horizontal = 14.dp, vertical = 10.dp),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val context = LocalContext.current
    val copyModifier = Modifier.pointerInput(message.id) {
        detectTapGestures(onLongPress = { copyToClipboard(context, message.text) })
    }
    if (message.fromUser) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Text(
                text = message.text,
                modifier = Modifier
                    .widthIn(max = 300.dp)
                    .background(
                        MaterialTheme.colorScheme.primary,
                        RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomEnd = 4.dp, bottomStart = 18.dp)
                    )
                    .then(copyModifier)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                color = MaterialTheme.colorScheme.onPrimary
            )
        }
    } else {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            Avatar()
            Spacer(Modifier.width(8.dp))
            Text(
                text = message.text,
                modifier = Modifier
                    .widthIn(max = 300.dp)
                    .background(
                        MaterialTheme.colorScheme.surfaceVariant,
                        RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomEnd = 18.dp, bottomStart = 4.dp)
                    )
                    .then(copyModifier)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HistoryScreen(
    items: List<Conversation>,
    selectedId: Long,
    onSelect: (Long) -> Unit,
    onTrash: () -> Unit,
    onNew: () -> Unit,
    onMoveToTrash: (Long) -> Unit
) {
    Scaffold(topBar = { TopAppBar(title = { Text("Historial") }) }) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(onClick = onNew, Modifier.fillMaxWidth()) { Text("Nueva conversación") }
            Button(onClick = onTrash, Modifier.fillMaxWidth()) { Text("Papelera") }
            if (items.isEmpty()) {
                Text("No hay conversaciones.")
            } else {
                items.forEach { c ->
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { onSelect(c.id) },
                            Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (c.id == selectedId) {
                                    MaterialTheme.colorScheme.secondary
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant
                                },
                                contentColor = MaterialTheme.colorScheme.onSurface
                            )
                        ) {
                            Text(c.title)
                        }
                        IconButton(onClick = { onMoveToTrash(c.id) }) {
                            Text("×")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MemoryScreen(
    items: List<MemoryItem>,
    onAdd: (String) -> Unit,
    onDelete: (Long) -> Unit
) {
    var text by remember { mutableStateOf("") }
    Scaffold(topBar = { TopAppBar(title = { Text("Memoria local") }) }) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Algo que Makoto debe recordar...") }
            )
            Button(
                onClick = {
                    onAdd(text)
                    text = ""
                },
                Modifier.fillMaxWidth()
            ) {
                Text("Guardar memoria")
            }
            HorizontalDivider()
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items, key = { it.id }) { item ->
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(item.text, Modifier.weight(1f))
                        IconButton(onClick = { onDelete(item.id) }) {
                            Text("×")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TrashScreen(
    items: List<Conversation>,
    onRestore: (Long) -> Unit,
    onDelete: (Long) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(topBar = { TopAppBar(title = { Text("Papelera") }) }) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Button(onClick = onBack, Modifier.fillMaxWidth()) { Text("Volver al historial") }
            Spacer(Modifier.height(12.dp))
            if (items.isEmpty()) {
                Text("La papelera está vacía.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(items, key = { it.id }) { c ->
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(c.title, Modifier.weight(1f))
                            IconButton(onClick = { onRestore(c.id) }) {
                                Text("↶")
                            }
                            IconButton(onClick = { onDelete(c.id) }) {
                                Text("×")
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen(
    selectedTree: Uri?,
    modelCount: Int,
    modelScanError: String?,
    onPick: () -> Unit,
    onClear: () -> Unit,
    threads: Int,
    onThreads: (Int) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(topBar = { TopAppBar(title = { Text("Configuración") }) }) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                "Modelo de IA",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                when {
                    modelScanError != null -> modelScanError
                    selectedTree == null -> "No hay una carpeta de modelos configurada."
                    else -> "Carpeta configurada. GGUF encontrados: $modelCount"
                }
            )
            Button(onClick = onPick, Modifier.fillMaxWidth()) {
                Text("📁")
                Spacer(Modifier.width(8.dp))
                Text("Seleccionar carpeta de modelos")
            }
            if (selectedTree != null) {
                Button(onClick = onClear, Modifier.fillMaxWidth()) {
                    Text("Quitar carpeta")
                }
            }
            HorizontalDivider()
            Text("Velocidad (hilos de CPU)", fontWeight = FontWeight.Bold)
            Text("Más hilos = respuestas más rápidas, pero más calor. Prueba y quédate con el que mejor te funcione. Se aplica en tu siguiente mensaje.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val cores = Runtime.getRuntime().availableProcessors()
                listOf(2, 3, 4, 6, 8).filter { it <= cores }.forEach { n ->
                    if (n == threads) {
                        Button(onClick = { onThreads(n) }) { Text("$n") }
                    } else {
                        TextButton(onClick = { onThreads(n) }) { Text("$n") }
                    }
                }
            }
            HorizontalDivider()
            Text("Makoto usa el selector de carpetas de Android. El modelo permanece fuera del APK.")
            Text("Esta versión 0.3 integra el motor GGUF local.")
            HorizontalDivider()
            Text("Makoto 0.3", fontWeight = FontWeight.Bold)
            Text("Creado por Carlos A. Reyes. © 2026. Todos los derechos reservados.")
            Text("Motor de inferencia: llama.cpp (licencia MIT). Los modelos de IA que cargues tienen sus propias licencias.")
            Button(onClick = onBack, Modifier.fillMaxWidth()) {
                Text("Volver al chat")
            }
        }
    }
}
