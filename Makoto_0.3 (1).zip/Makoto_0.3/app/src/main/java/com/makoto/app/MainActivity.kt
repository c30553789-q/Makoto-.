package com.makoto.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.makoto.app.ui.IntroScreen
import com.makoto.app.ui.MakotoApp
import com.makoto.app.ui.theme.MakotoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        setContent {
            MakotoTheme {
                var showIntro by remember { mutableStateOf(true) }
                if (showIntro) {
                    IntroScreen(onDone = { showIntro = false })
                } else {
                    MakotoApp()
                }
            }
        }
    }
}
