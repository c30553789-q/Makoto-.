package com.makoto.app.ai

import java.util.concurrent.atomic.AtomicBoolean

/**
 * Motor local sobre llama.cpp (JNI).
 * Contexto 2048, hasta 512 tokens por respuesta, 2–4 hilos.
 */
class LlamaCppEngine(
    private val nCtx: Int = 2048,
    private val maxTokens: Int = 300,
    defaultThreads: Int = 4
) : InferenceEngine {

    @Volatile
    private var threads: Int = defaultThreads

    private val loaded = AtomicBoolean(false)
    private val lock = Any()

    override val isReady: Boolean
        get() = loaded.get() && LlamaNative.loadError == null

    override fun loadModel(modelPath: String): Result<Unit> = synchronized(lock) {
        if (LlamaNative.loadError != null) {
            return Result.failure(LlamaNative.loadError!!)
        }
        unloadInternal()
        val code = LlamaNative.nativeLoad(modelPath, nCtx, threads)
        if (code != 0) {
            return Result.failure(IllegalStateException("nativeLoad falló con código $code"))
        }
        loaded.set(true)
        Result.success(Unit)
    }

    override fun loadModelFd(fd: Int): Result<Unit> = synchronized(lock) {
        if (LlamaNative.loadError != null) {
            return Result.failure(LlamaNative.loadError!!)
        }
        unloadInternal()
        val code = LlamaNative.nativeLoadFd(fd, nCtx, threads)
        if (code != 0) {
            return Result.failure(IllegalStateException("nativeLoadFd falló con código $code"))
        }
        loaded.set(true)
        Result.success(Unit)
    }

    override fun generate(prompt: String, onToken: (String) -> Unit): Result<Unit> = synchronized(lock) {
        if (!loaded.get()) {
            return Result.failure(IllegalStateException("Modelo no cargado"))
        }
        val tokenCallback = onToken
        val sink = object : LlamaNative.TokenSink {
            override fun onToken(token: String) {
                tokenCallback(token)
            }
        }
        val code = LlamaNative.nativeGenerate(prompt, maxTokens, sink)
        if (code != 0) {
            return Result.failure(IllegalStateException("nativeGenerate falló con código $code"))
        }
        Result.success(Unit)
    }

    override fun setThreads(n: Int) {
        threads = n.coerceIn(1, 16)
    }

    override fun stop() {
        runCatching { LlamaNative.nativeStop() }
    }

    override fun unload() = synchronized(lock) {
        unloadInternal()
    }

    private fun unloadInternal() {
        if (loaded.getAndSet(false)) {
            runCatching { LlamaNative.nativeUnload() }
        }
    }
}
